"""
	es un ejemplo 
"""
print("hola mundo");print("mas cosas")
input()
