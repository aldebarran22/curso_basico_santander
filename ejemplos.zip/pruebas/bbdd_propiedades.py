import sqlite3 as dbapi

print (dbapi.apilevel)
print (dbapi.threadsafety)
print(dbapi.paramstyle)

