# excepciones

def division(a, b): 
	return a / b

def calcular(): 
	division(1, 0)

calcular()
