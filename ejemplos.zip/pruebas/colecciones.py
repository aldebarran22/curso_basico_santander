# Colecciones:

L = [1,2,3,'uuuu',[90,88]]
print(L,L[0])

LL=L[::-1]
print(LL)
print(LL[1:])

print(type(LL))

t = (1,2,3)
print(t)

d={}
print(type(d))

# Pruebas con los constructores:
L1=list()
L2 = []

print(L1,L2)

t1=tuple()
t2=(3,4,5,7)
print("t1:",t1)
print(t2[0])

# Diccionarios:
d1 = {}
d2 = dict()

print(d1,d2)
print(type(d1),type(d2))

# Conjuntos:
c1 = set()
print(c1,type(c1))

c2 = {1,2,3,4,6,7}
print(c2,type(c2),end="")





