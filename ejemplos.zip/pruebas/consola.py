x = 5
y = 5.6
z = 34

print("\n%d %f %d" % (x,y,z))

nombre = input("enter your name:")
print("nombre:", nombre)

print(float("45.77"))
