# quitar repetidos a una lista
L=[1,2,3,3,1,1,16,6,5,3,2,1]
L2 = list(set(L))
print("L:",L)
print("L2:",L2)


