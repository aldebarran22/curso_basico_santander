pi = 3.141516
B = 2 * pi
print(B)
x = 2
y = x**4 + x**3 + x**2 + 10
print(y)
